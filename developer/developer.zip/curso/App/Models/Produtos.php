<?php

namespace App\Models;

use App\Models\Connect;

class Produtos{

    private $connect;

    public function __construct(){
        $connect = new Connect();
        $this->connect = $connect->connect();
    }

    public function all(){
        $sql = "select * from produtos";
        $listar = $this->connect->prepare($sql);
        $listar->execute();
        return $listar->fetchAll();
    }

}
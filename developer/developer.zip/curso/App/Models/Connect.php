<?php

namespace App\Models;

use PDO;

class Connect{

    public function connect(){
        $pdo = new PDO("mysql:host=localhost;dbname=loja_phpoo","root","root");
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
        return $pdo;
    }

}

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pagseguro</title>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css'/>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css'/>
</head>
<body>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">

            <h2>Pagar com pagseguro</h2>

            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis, facere aliquam voluptatum quia quo hic nobis facilis repellat beatae quod aut mollitia unde a veritatis dolor amet nam, tenetur laborum.
            </p>
            <a href="#" class="btn btn-primary btn-checkout">
                Pagar com pagseguro
            </a>

            <div id="message"></div>

        </div>
    </div>
    
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>
    <script type="text/javascript"
    src="https://stc.sandbox.pagseguro.uol.com.br/pagseguro/api/v2/checkout/pagseguro.lightbox.js">
    </script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.min.js'></script>
    <script src="assets/js/checkout.js"></script>
</body>
</html>
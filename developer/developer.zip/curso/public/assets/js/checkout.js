$(document).ready(function(){

    var btn_checkout = $(".btn-checkout");
    var message = $("#message");

    btn_checkout.on('click', function(event){
        event.preventDefault();
        
        $.ajax({
            url:'/ajax/checkout.php',
            dataType:'json',
            beforeSend: function(){
                message.html('Aguarde, fechando o pedido...');
            },
            success: function(retorno){

               var isOpenLightbox = PagSeguroLightbox(
                    retorno,
                     {
                        success : function(transactionCode) {
                            message.html('');
                            swal("Venda concluida", "Você pagou o seu pedido, agora aguarde a provação para seu acesso ser liberado", "success");
                        },
                        abort : function() {
                            message.html('');
                            swal("Erro", "Você fechou o lightbox", "warning");
                            // window.loaction.href = 'erro.php';
                        }
                    }
                );

                if (!isOpenLightbox){
                    location.href="https://sandbox.pagseguro.uol.com.br/v2/checkout/payment.html?code="+retorno.code;
                }
                
                // sem usar o lightbox
                // if(retorno.retorno == 'success'){
                //     window.location.href = retorno.url;
                // }else{
                //     alert('Erro ao pagar sua conta');
                // }

            },
            error: function(error){
                message.html('');
                console.log(error);
            }

        });

    });

});
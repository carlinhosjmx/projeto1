<?php

require "../../vendor/autoload.php";

use App\Classes\Pagseguro;
use App\Models\Produtos;

$dados = [
	'email' => 'xandecar@hotmail.com',
	'token' => 'FF579CC8863549A783664FDC85657678',
	"currency"=>"BRL",
	"reference"=>"REF1234",
	"senderName"=>"Jose Comprador",
	"senderAreaCode"=>"16",
	"senderPhone"=>"99999999",
	"senderEmail"=>"alecar2007@gmail.com",
	"shippingAddressRequired" => "false",
    "paymentMethodGroup1"=>"CREDIT_CARD", 
	"paymentMethodConfigKey1_1"=>"MAX_INSTALLMENTS_NO_INTEREST", 
	"paymentMethodConfigValue1_1"=>"5",
    "paymentMethodGroup2"=>"ONLINE_DEBIT", 
	"paymentMethodConfigKey2_1"=>"DISCOUNT_PERCENT", 
	"paymentMethodConfigValue2_1"=>"25.00"
];

$produtos = new Produtos;
$produtosCadastrados = $produtos->all();

$i = 1;
foreach($produtosCadastrados as $produto){
	$dados['itemId'.$i] = $produto->id;
	$dados['itemDescription'.$i] = $produto->produto_nome;
	$dados['itemAmount'.$i] = $produto->produto_valor;
	$dados['itemQuantity'.$i] = 1;
	$i++;
}

$url = "https://ws.sandbox.pagseguro.uol.com.br/v2/checkout";
$query = http_build_query($dados);

$pagseguro = new Pagseguro;
$retorno = $pagseguro->checkout($url,$query);

echo json_encode($retorno);

// if(!$retorno->code){
// 	echo json_encode([
// 		'retorno' => 'error'
// 	]);
// }else{
// 	$urlredirect = "https://sandbox.pagseguro.uol.com.br/v2/checkout/payment.html?code={$retorno->code}";
// 	echo json_encode(
// 		[
// 			'retorno' => 'success',
// 			'url' => $urlredirect
// 		]
// 	);
// }
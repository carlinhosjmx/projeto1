<?php

namespace App\Interfaces;

interface EnvironmentInterface {
	public function emailEnvironment();
	public function tokenEnvironment();
}